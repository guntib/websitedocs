# INTERNATIONAL BUSINESS MANAGEMENT CONSULTANT INC. — Website

This folder contains a single-page website you can host **for free**.

## Files
- `index.html` — your entire website (open it to view locally).
- `README.md` — this guide.

## Quick Preview (on your computer)
1. Double-click `index.html` — it will open in your browser.
2. Try the form — in **test mode** it shows a success message and logs to the console (no emails sent).

## Free Hosting Option A — Netlify Drop (fastest)
1. Go to Netlify Drop (search on the web).
2. Drag **`index.html`** into the page.
3. Netlify gives you a public link like `https://your-site-name.netlify.app` — done!

## Free Hosting Option B — GitHub Pages
1. Create a GitHub repo (e.g., `broker-site`).
2. Upload **`index.html`** to the root of the repo.
3. Go to **Settings → Pages** → set:
   - **Source:** Deploy from a branch
   - **Branch:** `main` and **Folder:** `/ (root)`
4. Save and wait 1–2 minutes. Your site will be live at `https://<yourname>.github.io/broker-site`.

## Make the form send you emails (free)
1. Create a free account at https://formspree.io/ and add a new form.
2. Copy the endpoint URL they give you, e.g. `https://formspree.io/f/abcd1234`.
3. Open `index.html` and set:
   ```js
   const USE_FORMSPREE = true;
   const FORM_ENDPOINT = "https://formspree.io/f/your-code";
   ```
4. Re-deploy (Netlify/GitHub Pages).

## Optional: Google Map Embed
In `index.html`, search for “Google Map embed” and uncomment the `<iframe>` block. It will show your Burlington office on the page.

---

**Owner:** Ansar H. Lakhani  
**Office:** 3070 Rotary Way, Unit 221, Burlington, Ontario, L7M 0H1, Canada

