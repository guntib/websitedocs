FINAL PACKAGE (only info@globalibmc.com)
1) Upload to public_html and Extract (overwrite).
2) Edit public_html/contact.php and set:
   $SMTP_PASS = "YOUR_INFO_EMAIL_PASSWORD";
3) Submit a test. Check public_html/smtp_log.txt if anything fails.
